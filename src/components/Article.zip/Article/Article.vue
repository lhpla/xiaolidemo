<template>
  <div>
    <div style="display:flex; flex:1; background: #59A586;justify-content: flex-end;">
      <button style="margin:10px; background:#F56C6C; color:white;border-radius: 5px;padding:5px 10px;">查看</button>
      <button style="margin:10px; background:#409EFF; color:white;border-radius: 5px;padding:5px 10px;">发布</button>
    </div>
    <el-card style="margin-top:20px;">
      <el-form :model="ruleForm"
               :rules="rules"
               ref="ruleForm"
               label-width="100px"
               class="demo-ruleForm">
        <el-form-item label="发表标题"
                      prop="name"
                      required>
          <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <el-form-item label="发表摘要"
                      prop="name"
                      required>
          <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <div style="display:flex; flex-direction:row;">
          <el-form-item label="作者"
                        required
                        style="flex:1;">
            <el-input v-model="ruleForm.name"></el-input>
          </el-form-item>
          <el-form-item label="类目"
                        prop="sl"
                        required
                        style="flex:1;">
            <el-select v-model="ruleForm.sl"
                       placeholder="请选择">
              <el-option label="Vue"
                         value="Vue"></el-option>
              <el-option label="React"
                         value="React"></el-option>
              <el-option label="Node.js"
                         value="Node.js"></el-option>
              <el-option label="性能优化"
                         value="性能优化"></el-option>
              <el-option label="JavaScript"
                         value="JavaScript"></el-option>
              <el-option label="小程序"
                         value="小程序"></el-option>
              <el-option label="工具类"
                         value="工具类"></el-option>
              <el-option label="其他"
                         value="其他"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="来源"
                        prop="sel"
                        required
                        style="flex:1;">
            <el-select v-model="ruleForm.sel"
                       placeholder="请选择">
              <el-option label="原创"
                         value="原创"></el-option>
              <el-option label="转载"
                         value="转载"></el-option>
              <el-option label="与他人合作"
                         value="与他人合作"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="重要性"
                        prop="region"
                        required
                        style="flex:1;">
            <el-select v-model="ruleForm.region"
                       placeholder="请选择">
              <el-option label="1"
                         value="1"></el-option>
              <el-option label="2"
                         value="2"></el-option>
              <el-option label="3"
                         value="3"></el-option>
              <el-option label="4"
                         value="4"></el-option>
              <el-option label="5"
                         value="5"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="发布时间"
                        prop="region"
                        required
                        style="flex:1;">
          </el-form-item>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: '',
  props: {
  },
  components: {

  },
  data () {
    return {
      ruleForm: {
        name: '',
        region: '',
        date1: '',
        date2: '',

      },
      name: [
        { required: true, message: '请输入活动名称', trigger: 'blur' },
        { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
      ],
      region: [
        { required: true, message: '请选择活动区域', trigger: 'change' }
      ],
      date1: [
        { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
      ],
      date2: [
        { type: 'date', required: true, message: '请选择时间', trigger: 'change' }
      ],



    }
  },
  methods: {

    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm (formName) {
      this.$refs[formName].resetFields();
    }
  },
  mounted () {

  },
  watch: {

  },
  computed: {

  }
}
</script>

<style scoped lang='scss'>
</style>